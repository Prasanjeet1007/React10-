import React from "react";

function Details(props){
  return(
  
    <p className="info">{props.phone11}</p>
  
  );
}

export default Details;