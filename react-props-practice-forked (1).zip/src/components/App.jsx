import React from "react";
import Card from "./Card";
import contacts from "../contacts";
import Avatar from "./Avatar";
function App() {
  return (
    <div>
       <h1 className="heading">My Contacts</h1>
       <Avatar
img="https://media-exp1.licdn.com/dms/image/C4E03AQH32xhWrKoBoA/profile-displayphoto-shrink_400_400/0/1644258770694?e=1657756800&v=beta&t=gKqv2CPHHtPDGBGgtFXY2cMHxZnN8W1scoAtf-kBe3Y"       />
    <Card 
    name={contacts[0].name}
    img={contacts[0].imgURL}
    phone={contacts[0].phone}
    email={contacts[0].email}
    />
    <Card
      name={contacts[1].name}
      img={contacts[1].imgURL}
      phone={contacts[1].phone}
      email={contacts[1].email}
    
    />
    <Card 
      name={contacts[2].name}
    img={contacts[2].imgURL}
    phone={contacts[2].phone}
    email={contacts[2].email}
   />
</div>
  );
}

export default App;
